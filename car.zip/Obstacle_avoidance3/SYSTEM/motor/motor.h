#ifndef __MOTOR_H_
#define __MOTOR_H_

#include "stm32f10x.h"
#include "Math.h"
#include "delay.h"
#include "stm32f10x.h"

void TIM4_PWM_Init(unsigned short arr,unsigned short psc);
void SetMotorSpeed(unsigned char ucChannel,unsigned char cSpeed,unsigned char cTurn);

void run(unsigned char speed,int time);       //ǰ������
void brake(int time);               //ɲ������
void left(unsigned char speed,int time);      //��ת����
void spin_left(unsigned char speed,int time); //����ת����
void right(unsigned char speed,int time);     //��ת����
void spin_right(unsigned char speed,int time);//����ת����
void back(unsigned char speed,int time);      //���˺���
void testMotor(unsigned char speed,int time);


//�������IO���� 
/* 
LEFT_MOTOR_GO	  PB8	�����������
LEFT_MOTOR_PWM	PB9	����PWM

RIGHT_MOTOR_GO	PA6     �ҵ���������
RIGHT_MOTOR_PWM	PB10	  �ҵ�����PWM
 */
 
#define LEFT_MOTOR_GO             GPIO_Pin_7
#define LEFT_MOTOR_GO_GPIO        GPIOB
#define LEFT_MOTOR_GO_SET         GPIO_SetBits(LEFT_MOTOR_GO_GPIO,LEFT_MOTOR_GO)
#define LEFT_MOTOR_GO_RESET       GPIO_ResetBits(LEFT_MOTOR_GO_GPIO,LEFT_MOTOR_GO)

#define LEFT_MOTOR_PWM            GPIO_Pin_8
#define LEFT_MOTOR_PWM_GPIO       GPIOB
#define LEFT_MOTOR_PWM_SET        GPIO_SetBits(LEFT_MOTOR_PWM_GPIO,LEFT_MOTOR_PWM)
#define LEFT_MOTOR_PWM_RESET      GPIO_ResetBits(LEFT_MOTOR_PWM_GPIO,LEFT_MOTOR_PWM)

#define RIGHT_MOTOR_GO             GPIO_Pin_4
#define RIGHT_MOTOR_GPIO           GPIOA
#define RIGHT_MOTOR_GO_SET         GPIO_SetBits(RIGHT_MOTOR_GPIO,RIGHT_MOTOR_GO)
#define RIGHT_MOTOR_GO_RESET       GPIO_ResetBits(RIGHT_MOTOR_GPIO,RIGHT_MOTOR_GO)

#define RIGHT_MOTOR_PWM            GPIO_Pin_9
#define RIGHT_MOTOR_PWM_GPIO       GPIOB
#define RIGHT_MOTOR_PWM_SET        GPIO_SetBits(RIGHT_MOTOR_PWM_GPIO,RIGHT_MOTOR_PWM)
#define RIGHT_MOTOR_PWM_RESET      GPIO_ResetBits(RIGHT_MOTOR_PWM_GPIO,RIGHT_MOTOR_PWM)

#define CLOCKWISE 0
#define ANTICLOCKWISE 1
#define NON_TURN 2

#define RIGHT 0
#define LEFT 1

#endif

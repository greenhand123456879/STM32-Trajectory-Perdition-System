#ifndef __SERVER_H_
#define __SERVER_H_

#include "stm32f10x.h"
#include "delay.h"
#include "UltrasonicWave.h"

void TIM5_PWM_Init(u16 arr,u16 psc);
void SetJointAngle(float angle);
int front_detection(void);
int left_detection(void);
int right_detection(void);
int left_45_dectection(void);
int right_45_dectection(void);
int random_dectection(float angle);

#endif 

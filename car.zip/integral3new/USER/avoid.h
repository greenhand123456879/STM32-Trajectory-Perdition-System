#ifndef __AVOID_H_
#define	__AVOID_H_
#include "stm32f10x.h"
#include "motor.h"
#include "keyscan.h"
#include "UltrasonicWave.h"
#include "steerengine.h"
#include "remote.h"
#include "delay.h"
#include "sys.h"

//��Ҫ���Ϲ��ܺ���
void Avoid_Init(void);
void Avoid_Ultra(void);

#endif

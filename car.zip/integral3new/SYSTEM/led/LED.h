#ifndef __LED_H_
#define __LED_H_

#include "stm32f10x.h"


// LED D3��IO�ڶ���
#define LED_D3_PIN       GPIO_Pin_6
#define LED_D3_PIN_GPIO  GPIOB
#define LED_D3_SET       GPIO_SetBits(LED_D3_PIN_GPIO,LED_D3_PIN)		//��
#define LED_D3_RESET     GPIO_ResetBits(LED_D3_PIN_GPIO,LED_D3_PIN)	//��

// LED D4��IO�ڶ���
#define LED_D4_PIN       GPIO_Pin_6
#define LED_D4_PIN_GPIO  GPIOA
#define LED_D4_SET       GPIO_SetBits(LED_D4_PIN_GPIO,LED_D4_PIN)		//��
#define LED_D4_RESET     GPIO_ResetBits(LED_D4_PIN_GPIO,LED_D4_PIN)	//��

void LED_Init(void);

#endif

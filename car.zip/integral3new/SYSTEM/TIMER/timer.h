#ifndef __TIMER_H_
#define __TIMER_H_
#include "sys.h"
#include "delay.h"

extern u8 front_angle;
extern u8 flag_avoid;
//extern u8 key;
void Timer3_Init(u16 arr,u16 psc);
#endif

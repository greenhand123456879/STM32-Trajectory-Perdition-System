#ifndef __STEERENGINE_H_
#define __STEERENGINE_H_

#include "stm32f10x.h"
#include "delay.h"
#include "UltrasonicWave.h"

void TIM5_PWM_Init(u16 arr,u16 psc);
void Set_Angle(float angle);
int Front_Detection(void);
int Left_Detection(void);
int Right_Detection(void);
int Left_45_Detection(void);
int Right_45_Detection(void);
int Random_Detection(float angle);

#endif 
